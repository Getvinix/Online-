# Putting Peruwa Academy Records online (Vercel + Supabase)

Vercel hosts the website. Supabase (free plan is enough) stores the data and handles logins.
Total time: about 20 minutes.

## 1. Create the database (Supabase)
1. Go to https://supabase.com, sign up, and click **New project**. Choose a strong database password and a nearby region.
2. When it is ready, open **SQL Editor > New query**, paste the entire contents of `schema.sql`, and click **Run**.
3. Open **Authentication > Sign In / Providers** (or "Providers > Email") and turn **OFF** "Allow new users to sign up".
4. Open **Authentication > Users > Add user > Create new user**. Enter YOUR email and a password and tick **Auto Confirm User**.
   The first account created automatically becomes the **administrator**.
5. Open **Project Settings > API** and copy three values:
   - **Project URL**
   - **anon public** key
   - **service_role** key (SECRET: never share it or put it in the website code)

## 2. Publish on Vercel
1. Create a free GitHub account, make a new repository, and upload everything in this folder (`index.html`, `api/`, `package.json`, `schema.sql`, ...).
2. Go to https://vercel.com, **Add New > Project**, import that repository. Leave Framework as **Other**; no build settings needed.
3. Before clicking Deploy, open **Environment Variables** and add:
   | Name | Value |
   |---|---|
   | `SUPABASE_URL` | the Project URL |
   | `SUPABASE_ANON_KEY` | the anon public key |
   | `SUPABASE_SERVICE_ROLE_KEY` | the service_role key |
4. Click **Deploy**. (Alternative without GitHub: install Node.js, then run `npx vercel` inside this folder.)

## 3. First use
1. Open your Vercel link and sign in with the admin email and password.
2. **Move your existing records:** on your old copy of the system click **Save a backup file**. In the new online system go to **Overview > Load a backup file** and choose it. Everything uploads to the cloud.
3. Open **Users & Access** and create an account for each teacher (role: Teacher).

## Who can do what
| | Teacher | Administrator |
|---|---|---|
| Enter / edit marks (Marks Entry) | Yes | Yes |
| Verify Marks checklist | Yes | Yes |
| Classes, subjects, exams, students | No | Yes |
| Report cards, rankings, gender report, trends, score sheets | No | Yes |
| Delete anything, backups, create/delete users | No | Yes |

These limits are enforced by the database itself, not just hidden buttons, so a teacher cannot get around them.

## Notes
- Several people can work at the same time. The app saves automatically and refreshes other people's changes every minute (or press **Refresh**).
- Keep downloading a backup file now and then from **Overview**.
- To change which tabs teachers see, edit `TEACHER_TABS` in `index.html`. To let teachers also change other data you would need to change the policies in `schema.sql` too.
