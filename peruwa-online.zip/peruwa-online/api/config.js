// Gives the browser the PUBLIC Supabase settings (safe to expose: the anon key
// can only do what the database security rules in schema.sql allow).
module.exports = (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    url: process.env.SUPABASE_URL || '',
    anonKey: process.env.SUPABASE_ANON_KEY || ''
  });
};
