// Admin-only user management: list, create, change role / reset password, delete.
// Uses the SECRET service-role key, which never leaves the server.
const { createClient } = require('@supabase/supabase-js');

function serviceClient() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}

async function requireAdmin(req, sb) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token) return null;
  const { data, error } = await sb.auth.getUser(token);
  if (error || !data || !data.user) return null;
  const { data: prof } = await sb.from('profiles').select('role').eq('id', data.user.id).maybeSingle();
  return prof && prof.role === 'admin' ? data.user : null;
}

const ROLES = ['admin', 'teacher'];

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return res.status(500).json({ error: 'Server is missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY.' });
  }
  const sb = serviceClient();
  const me = await requireAdmin(req, sb);
  if (!me) return res.status(403).json({ error: 'Administrators only.' });

  try {
    if (req.method === 'GET') {
      const { data, error } = await sb.from('profiles')
        .select('id, full_name, email, role, created_at').order('created_at');
      if (error) throw error;
      return res.status(200).json({ users: data });
    }

    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});

    if (req.method === 'POST') {
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      const full_name = String(body.full_name || '').trim();
      const role = body.role;
      if (!email || !full_name) return res.status(400).json({ error: 'Name and email are required.' });
      if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
      if (!ROLES.includes(role)) return res.status(400).json({ error: 'Invalid role.' });

      const { data, error } = await sb.auth.admin.createUser({
        email, password, email_confirm: true, user_metadata: { full_name }
      });
      if (error) return res.status(400).json({ error: error.message });

      const { error: pe } = await sb.from('profiles')
        .upsert({ id: data.user.id, full_name, email, role }, { onConflict: 'id' });
      if (pe) {
        await sb.auth.admin.deleteUser(data.user.id);
        throw pe;
      }
      return res.status(200).json({ ok: true });
    }

    if (req.method === 'PATCH') {
      const id = body.id;
      if (!id) return res.status(400).json({ error: 'Missing user id.' });
      if (body.role !== undefined) {
        if (!ROLES.includes(body.role)) return res.status(400).json({ error: 'Invalid role.' });
        if (id === me.id) return res.status(400).json({ error: 'You cannot change your own role.' });
        const { error } = await sb.from('profiles').update({ role: body.role }).eq('id', id);
        if (error) throw error;
      }
      if (body.full_name !== undefined) {
        const { error } = await sb.from('profiles').update({ full_name: String(body.full_name).trim() }).eq('id', id);
        if (error) throw error;
      }
      if (body.password !== undefined) {
        if (String(body.password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
        const { error } = await sb.auth.admin.updateUserById(id, { password: String(body.password) });
        if (error) return res.status(400).json({ error: error.message });
      }
      return res.status(200).json({ ok: true });
    }

    if (req.method === 'DELETE') {
      const id = (req.query && req.query.id) || body.id;
      if (!id) return res.status(400).json({ error: 'Missing user id.' });
      if (id === me.id) return res.status(400).json({ error: 'You cannot delete your own account.' });
      const { error } = await sb.auth.admin.deleteUser(id);
      if (error) return res.status(400).json({ error: error.message });
      return res.status(200).json({ ok: true });
    }

    res.setHeader('Allow', 'GET, POST, PATCH, DELETE');
    return res.status(405).json({ error: 'Method not allowed.' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message || 'Server error.' });
  }
};
