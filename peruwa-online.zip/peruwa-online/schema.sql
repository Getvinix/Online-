-- Peruwa Academy School Records: database setup for Supabase.
-- Paste this whole file into Supabase > SQL Editor > New query, then click Run.
-- It is safe to run more than once.

-- 1) Who can use the system, and in what role ------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  role text not null default 'teacher' check (role in ('admin','teacher')),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- Returns the role of the signed-in user ('admin' / 'teacher'), or null if they have no access.
create or replace function public.app_role()
returns text
language sql
security definer
stable
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

-- The very first account created becomes the administrator.
-- Every later account gets NO access until the admin creates it from the Users tab,
-- so a stranger who signs up by themselves can never see any school data.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles) then
    insert into public.profiles (id, full_name, email, role)
    values (new.id,
            coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
            new.email,
            'admin');
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

drop policy if exists "profiles read own or admin" on public.profiles;
create policy "profiles read own or admin" on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.app_role() = 'admin');
-- No insert/update/delete policies: profiles are changed only by the server (api/users.js).

-- 2) School data tables ------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['classes','subjects','exams','students','marks','corrections'] loop
    execute format('create table if not exists public.%I (id text primary key, data jsonb not null)', t);
    execute format('alter table public.%I enable row level security', t);

    -- Everyone with an account can read.
    execute format('drop policy if exists "read" on public.%I', t);
    execute format('create policy "read" on public.%I for select to authenticated using (public.app_role() is not null)', t);

    -- Administrators can do everything.
    execute format('drop policy if exists "admin all" on public.%I', t);
    execute format('create policy "admin all" on public.%I for all to authenticated using (public.app_role() = ''admin'') with check (public.app_role() = ''admin'')', t);
  end loop;
end $$;

-- 3) Teachers: may ADD and CHANGE marks (and the correction log). Nothing else, never delete.
do $$
declare t text;
begin
  foreach t in array array['marks','corrections'] loop
    execute format('drop policy if exists "teacher insert" on public.%I', t);
    execute format('create policy "teacher insert" on public.%I for insert to authenticated with check (public.app_role() = ''teacher'')', t);
    execute format('drop policy if exists "teacher update" on public.%I', t);
    execute format('create policy "teacher update" on public.%I for update to authenticated using (public.app_role() = ''teacher'') with check (public.app_role() = ''teacher'')', t);
  end loop;
end $$;
